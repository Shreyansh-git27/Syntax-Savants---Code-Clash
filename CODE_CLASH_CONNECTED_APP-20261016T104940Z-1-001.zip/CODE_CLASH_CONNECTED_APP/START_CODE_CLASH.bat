@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  start "CODE CLASH server" cmd /k "py -m http.server 8765 --bind 127.0.0.1"
) else (
  start "CODE CLASH server" cmd /k "python -m http.server 8765 --bind 127.0.0.1"
)
timeout /t 2 /nobreak >nul
start "" "http://127.0.0.1:8765/index.html"
