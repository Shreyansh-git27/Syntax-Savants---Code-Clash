/* CODE CLASH shared read-only public client. Never put ESP32 device tokens or service-role keys here. */
(function(){
 'use strict';
 const KEY='code-clash-public-settings-v1';
 const defaultUrl='https://deesdlgwviyqfedjcnkx.supabase.co';
 const save=(url,key)=>{url=String(url||'').trim().replace(/\/+$/,'');key=String(key||'').trim();
  if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url))throw Error('Enter a valid Supabase project URL.');
  if(!key || key.startsWith('sb_secret_') || key.startsWith('sb_service_') || key.includes('service_role'))throw Error('Use the publishable/anon key, NEVER a secret, service-role or device token.');
  if(!key.startsWith('sb_publishable_')&&!/^eyJ[A-Za-z0-9_.-]+$/.test(key))throw Error('Invalid publishable / legacy anon key format.');
  if(key.startsWith('eyJ')){try{const payload=JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')));if(payload.role!=='anon')throw Error('Only legacy anon JWT is allowed (role must be anon).')}catch(e){throw Error('Invalid or unsafe legacy JWT: '+e.message)}}
  localStorage.setItem(KEY,JSON.stringify({url,key}));
 };
 const config=()=>{let c=null;try{c=JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){}
  if(!c||!c.url||!c.key)throw Error('Not configured. Open CODE CLASH Home and enter your public Supabase key.');return c;};
 const request=async(path,opts={})=>{
  const {url,key}=config();const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),10000);
  try{const r=await fetch(url+path,{method:opts.method||'GET',headers:{apikey:key,...(key.startsWith('sb_publishable_')?{}:{Authorization:'Bearer '+key}),Accept:'application/json',...(opts.body?{'Content-Type':'application/json'}:{})},body:opts.body?JSON.stringify(opts.body):undefined,cache:'no-store',signal:ctrl.signal});
   if(!r.ok){let detail=(await r.text()).slice(0,300);throw Error('HTTP '+r.status+' '+detail)}return await r.json();
  }finally{clearTimeout(timer)};
 };
 const readSeats=async(area,capacity)=>{
  const params=new URLSearchParams({select:'seat_number,seating_groups!inner(area_code,frontend_id),occupancy_state(state,updated_at,last_observed_at)', 'seating_groups.area_code':'eq.'+area,limit:'600'});
  const rows=await request('/rest/v1/seats?'+params.toString());
  if(!Array.isArray(rows))throw Error('Invalid seating response');
  if(rows.length!==capacity)throw Error(area+' database seat count mismatch: '+rows.length+'/'+capacity+' (check RLS and SQL setup)');
  const groups=Object.create(null),seen=new Set();
  for(const row of rows){const g=Array.isArray(row.seating_groups)?row.seating_groups[0]:row.seating_groups;
   if(!g||g.area_code!==area||!g.frontend_id)throw Error('Seating group mapping missing');
   const i=Number(row.seat_number),id=g.frontend_id;if(!Number.isInteger(i)||i<1||i>50)throw Error('Invalid seat number '+id+'/'+i);
   const code=id+'/'+i;if(seen.has(code))throw Error('Duplicate seat '+code);seen.add(code);
   const occupancy=Array.isArray(row.occupancy_state)?row.occupancy_state[0]:row.occupancy_state;
   const status=occupancy?.state==='occupied'?true:occupancy?.state==='available'?false:null;
   (groups[id]??={})[i]=status;
  }
  return {groups,updatedAt:Date.now(),count:rows.length,known:rows.filter(r=>{const o=Array.isArray(r.occupancy_state)?r.occupancy_state[0]:r.occupancy_state;return o?.state==='available'||o?.state==='occupied'}).length};
 };
 const classrooms=(day,start,end)=>request('/rest/v1/rpc/get_classroom_availability',{method:'POST',body:{p_date:day,p_start:start,p_end:end}});
 const indicator=(message,kind)=>{const el=document.getElementById('ccIndicator');if(el){el.textContent=message;el.className='cc-indicator '+(kind||'')}};
 window.Campus={save,config,readSeats,classrooms,indicator,defaultUrl};
})();
