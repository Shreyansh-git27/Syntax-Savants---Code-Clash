CODE CLASH — Connected Smart Campus Frontend

WINDOWS START (Python installed):
1. Extract this ZIP completely (right click → Extract All).
2. Double-click START_CODE_CLASH.bat.
3. The browser should open http://127.0.0.1:8765/index.html
4. Enter your Supabase publishable/anon key, NOT device token or service-role key.
   Project URL is prefilled with the shared project URL.
5. Click Save & test. You should see 112 Grains & Gossip seats returned.
6. Open Grains & Gossip / Bits & Bites / Library / Classroom Vacancy cards.

IF THE BAT FILE DOES NOT START:
- Open Command Prompt inside the extracted folder.
- Run: py -m http.server 8765 --bind 127.0.0.1
- Open: http://127.0.0.1:8765/index.html
- Or run python -m http.server 8765 --bind 127.0.0.1

DO NOT OPEN index.html directly using file://. A local HTTP server is needed for
stable shared configuration and browser API requests.

SUPABASE PUBLIC KEY:
Supabase Dashboard → Project Settings → API Keys → Publishable key
(use legacy anon key if publishable keys unavailable).
Never use the service_role key, sb_secret_, ESP32 device token, or personal passwords.

WHAT CONNECTS:
Grains & Gossip: public.seats joined to seating_groups/occupancy_state, area GRAINS_GOSSIP (112).
Bits & Bites: same tables, area BITS_BITES (175).
Library: same tables, area LIBRARY (237).
Classroom: POST public.get_classroom_availability(p_date,p_start,p_end) (62 results).
Reads refresh every ~4 seconds on open seating pages, with no DB writes.
Sensor readings must still arrive via the already deployed ingestion Edge Functions.

PROTECTION:
Unknown or fault statuses are not shown as free, nor offered in group recommendations.
Canteen and library live pages are read-only. Classroom booking requests are demo-only
and disabled for safe read-only production integration.
These are the latest DATABASE states, not proof that all Wokwi hardware is connected.
If a Supabase request fails, the UI marks the database unavailable instead of claiming live data.

TROUBLESHOOTING:
- HTTP 401/403: check correct publishable/anon key and project URL.
- HTTP 404 on classrooms: function was not deployed or not exposed to the API.
- Wrong seat count: RLS or seating group mapping differs from the database schema.
- Browser network/CORS issues: run local server instead of file:// and verify project URL.
- Do not change or rerun setup SQL just to troubleshoot a frontend error.
- Frontend only receives read-only public status and does not contain device credentials.

STATUS:
Frontend files generated and local JS syntax validation performed.
No live remote Supabase request or browser-to-database verification was performed here:
confirm using Save & test and toggle a sensor to check the matching seat updates.
